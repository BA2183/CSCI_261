#include <SFML\Graphics.hpp>
#include "Triangle.hpp"
using namespace sf;

#include <vector>
using namespace std;

class ScaleneTriangle : public Triangle {
    bool setCoordinates(Vector2f ver1, Vector2f ver2, Vector2f ver3) {
        float sideOne, sideTwo, sideThree;
    }
};