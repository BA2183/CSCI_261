#include <SFML\Graphics.hpp>
#include "Triangle.hpp"
using namespace sf;

#include <vector>
using namespace std;

class IsoscelesTriangle: public Triangle {
    public:
        bool setCoordinates(Vector2f ver1, Vector2f ver2, Vector2f ver3) {

        };
};